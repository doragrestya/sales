-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 05 Feb 2023 pada 16.01
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sales`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang`
--

CREATE TABLE `barang` (
  `IdBarang` varchar(7) NOT NULL,
  `NamaBarang` varchar(50) NOT NULL,
  `Keterangan` varchar(100) NOT NULL,
  `Satuan` varchar(20) NOT NULL,
  `IdPengguna` varchar(7) NOT NULL,
  `IdSupplier` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `barang`
--

INSERT INTO `barang` (`IdBarang`, `NamaBarang`, `Keterangan`, `Satuan`, `IdPengguna`, `IdSupplier`) VALUES
('PR01', 'Kompor Tanam BI 0321 L', 'Kompor', 'unit', 'USR01', 'SP01'),
('PR04', 'Beras Solok', 'Beras', 'kilogram', 'USR04', 'SP04'),
('PR05', 'Laptop Asus', 'Laptop', 'unit', 'USR05', 'SP05'),
('PR06', 'Mouse Logitech', 'Mouse', 'unit', 'USR06', 'SP06'),
('PR07', 'HVS A4', 'Alat Tulis', 'Rim/lembar', 'USR07', 'SP07'),
('PR08', 'HP Android 64GB', 'Handphone', 'unit', 'USR08', 'SP08'),
('PR09', 'Mug Mini', 'Gelas', 'pcs', 'USR09', 'SP08'),
('USR20', 'Mouse', 'new', 'unit', 'USR02', 'SP05');

-- --------------------------------------------------------

--
-- Struktur dari tabel `hakakses`
--

CREATE TABLE `hakakses` (
  `IdAkses` varchar(7) NOT NULL,
  `NamaAkses` varchar(50) NOT NULL,
  `Keterangan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `hakakses`
--

INSERT INTO `hakakses` (`IdAkses`, `NamaAkses`, `Keterangan`) VALUES
('AR01', 'Administrator', 'Memiliki akses penuh ke seluruh tabel'),
('AR02', 'Supervisor', 'Dapat melihat data dari semua bagian department'),
('AR03', 'AdminUser', 'Memiliki akses penuh ke tabel pengguna'),
('AR04', 'AdminEmployee', 'Memiliki akses untuk CRUD ke tabel karyawan'),
('AR05', 'AdminSales', 'Memiliki akses untuk CRUD ke tabel penjualan'),
('AR06', 'UserPurchase', 'Memiliki akses untuk CRUD ke tabel pembelian'),
('AR07', 'UserSales', 'Memiliki akses untuk memperbarui penjualan'),
('AR08', 'UserWarehouse', 'Memiliki akses untuk CRUD ke tabel barang'),
('AR09', 'UserFinancial', 'Memiliki akses untuk CRUD ke tabel keuangan'),
('AR10', 'UserGuest', 'Dapat melihat data barang');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pelanggan`
--

CREATE TABLE `pelanggan` (
  `IdPelanggan` varchar(7) NOT NULL,
  `NamaPelanggan` varchar(50) NOT NULL,
  `NomorTelepon` varchar(15) NOT NULL,
  `AlamatPelanggan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `pelanggan`
--

INSERT INTO `pelanggan` (`IdPelanggan`, `NamaPelanggan`, `NomorTelepon`, `AlamatPelanggan`) VALUES
('P001', 'Muzzamil', '082287162711', 'Bandung'),
('P004', 'Agam', '08228711234', 'Mesir'),
('P005', 'Arya', '082287111111', 'Jakarta'),
('P006', 'Dinda', '0822871122234', 'Jakarta'),
('P007', 'Arya', '082287111111', 'Jakarta'),
('P008', 'Wardah', '082287111231', 'Jakarta'),
('P009', 'Rizky', '082287111212', 'Jakarta');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembelian`
--

CREATE TABLE `pembelian` (
  `IdPembelian` varchar(7) NOT NULL,
  `JumlahPembelian` int(11) NOT NULL,
  `HargaBeli` double NOT NULL,
  `IdPengguna` varchar(7) NOT NULL,
  `IdBarang` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `pembelian`
--

INSERT INTO `pembelian` (`IdPembelian`, `JumlahPembelian`, `HargaBeli`, `IdPengguna`, `IdBarang`) VALUES
('P001', 2, 3000000, 'USR01', 'PR01'),
('P004', 5, 1500000, 'USR04', 'PR04'),
('P005', 2, 3750000, 'USR05', 'PR05'),
('P006', 3, 4500000, 'USR06', 'PR06'),
('P007', 1, 2500000, 'USR07', 'PR07'),
('P008', 2, 1500000, 'USR08', 'PR08'),
('P009', 2, 7000000, 'USR09', 'PR09'),
('P011', 2, 3000000, 'USR01', 'PR01'),
('P014', 5, 1500000, 'USR04', 'PR04'),
('P015', 2, 4000000, 'USR05', 'PR05'),
('P016', 3, 4500000, 'USR06', 'PR06'),
('P017', 1, 2500000, 'USR07', 'PR07'),
('P018', 1, 3500000, 'USR08', 'PR08'),
('P019', 2, 7000000, 'USR09', 'PR09');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengguna`
--

CREATE TABLE `pengguna` (
  `IdPengguna` varchar(7) NOT NULL,
  `NamaPengguna` varchar(50) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `NamaDepan` varchar(50) NOT NULL,
  `NamaBelakang` varchar(50) NOT NULL,
  `NoHP` varchar(15) NOT NULL,
  `Alamat` text NOT NULL,
  `IdAkses` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `pengguna`
--

INSERT INTO `pengguna` (`IdPengguna`, `NamaPengguna`, `Password`, `NamaDepan`, `NamaBelakang`, `NoHP`, `Alamat`, `IdAkses`) VALUES
('USR01', 'Dora Grestya', '71579c496206dc942f70', 'Dora', 'Grestya', '081123293936', 'Solok', 'AR01'),
('USR02', 'Joko Widodo', '350d4cf4960bf70710dc', 'Joko', 'Widodo', '0811232369403', 'Solo', 'AR02'),
('USR03', 'Siti Saadiyah', 'c01df6ed48ef74592990', 'Siti', 'Saadiyah', '081123234566', 'Batu Sangkar', 'AR03'),
('USR04', 'Davina Julianti', '49d689955f486274d4e2', 'Davina', 'Julianti', '08234245525', 'Solok', 'AR04'),
('USR05', 'Arsyad Hamidi', 'd3042a18e4ec38f96686', 'Arsyad', 'Hamidi', '08112332333221', 'Padang', 'AR05'),
('USR06', 'Aldy Pratama', 'b24f9978ebe96b1b5078', 'Aldy', 'Pratama', '08123452637281', 'Pekanbaru', 'AR06'),
('USR07', 'Annisa Gusvera', '301b96488b077ba8f9a4', 'Annisa', 'Gusvera', '08232153122', 'Pasaman', 'AR07'),
('USR08', 'Satria Putra', '235e8cbdc61f694d398a', 'Satria', 'Putra', '082323456789', 'Painan', 'AR08'),
('USR09', 'Fikri Ilmi', '19da9ebef1ca88a6cb3f', 'Fikri', 'Ilmi', '082334453453', 'Pariaman', 'AR09'),
('USR10', 'Hexa Ariantika', 'c223356b7b1c5dbfcbc3', 'Hexa', 'Ariantika', '08234452534534', 'Payakumbuh', 'AR10'),
('USR11', 'oya', 'oya', 'oya', 'tya', '0823562216671', 'baru', 'AR01'),
('USR12', 'oyah', 'oyah', 'oyah', 'oyah', '081123293936', 'eee', 'AR01'),
('USR13', 'dia', 'dia', 'aku', 'dia', '081123293936', 'jl', 'AR02');

-- --------------------------------------------------------

--
-- Struktur dari tabel `penjualan`
--

CREATE TABLE `penjualan` (
  `IdPenjualan` varchar(7) NOT NULL,
  `JumlahPenjualan` int(11) NOT NULL,
  `HargaPenjualan` double NOT NULL,
  `IdPengguna` varchar(7) NOT NULL,
  `IdBarang` varchar(7) NOT NULL,
  `IdPelanggan` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `penjualan`
--

INSERT INTO `penjualan` (`IdPenjualan`, `JumlahPenjualan`, `HargaPenjualan`, `IdPengguna`, `IdBarang`, `IdPelanggan`) VALUES
('S001', 2, 5000000, 'USR01', 'PR01', 'P001'),
('S004', 4, 2000000, 'USR04', 'PR04', 'P004'),
('S005', 2, 5000000, 'USR05', 'PR05', 'P005'),
('S006', 1, 6000000, 'USR06', 'PR06', 'P006'),
('S007', 1, 3000000, 'USR07', 'PR07', 'P007'),
('S008', 2, 2000000, 'USR08', 'PR08', 'P008'),
('S009', 1, 8000000, 'USR09', 'PR09', 'P009'),
('S011', 2, 3000000, 'USR01', 'PR01', ''),
('S014', 5, 2000000, 'USR04', 'PR04', ''),
('S015', 2, 4000000, 'USR05', 'PR05', ''),
('S016', 3, 5000000, 'USR06', 'PR06', ''),
('S017', 1, 3000000, 'USR07', 'PR07', ''),
('S019', 2, 7000000, 'USR09', 'PR09', 'P002'),
('S021', 2, 600000, 'USR14', 'PR05', 'P002');

-- --------------------------------------------------------

--
-- Struktur dari tabel `supplier`
--

CREATE TABLE `supplier` (
  `IdSupplier` varchar(7) NOT NULL,
  `NamaSupplier` varchar(50) NOT NULL,
  `NomorTelepon` varchar(15) NOT NULL,
  `AlamatSupplier` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `supplier`
--

INSERT INTO `supplier` (`IdSupplier`, `NamaSupplier`, `NomorTelepon`, `AlamatSupplier`) VALUES
('SP01', 'PT.SUFINDO MAS JAYA', '082342324333', 'Jakarta'),
('SP02', 'UD. Jaya Sentosa', '0823212134567', 'Bandung'),
('SP03', 'PT.TRI JAYA KUSUMA', '082342324333', 'Jakarta'),
('SP04', 'PT.KARUNA JAYA', '082342324333', 'Jakarta'),
('SP05', 'PT.SEMEN PADANG INDONESIA', '082342324333', 'Padang'),
('SP06', 'PT.SINARMAS', '082342324333', 'Jakarta'),
('SP07', 'PT.ANGGI JAYA', '082342324333', 'Jakarta'),
('SP08', 'UD. BAREH SOLOK', '082342324333', 'Solok'),
('SP09', 'PT.ADI MAKMUR', '082342324333', 'Bali'),
('SP10', 'PT.HARAPAN JAYA', '082342324333', 'Jakarta');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`IdBarang`),
  ADD KEY `IdPengguna` (`IdPengguna`),
  ADD KEY `IdSupplier` (`IdSupplier`);

--
-- Indeks untuk tabel `hakakses`
--
ALTER TABLE `hakakses`
  ADD PRIMARY KEY (`IdAkses`);

--
-- Indeks untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`IdPelanggan`);

--
-- Indeks untuk tabel `pembelian`
--
ALTER TABLE `pembelian`
  ADD PRIMARY KEY (`IdPembelian`),
  ADD KEY `IdPengguna` (`IdPengguna`),
  ADD KEY `IdBarang` (`IdBarang`);

--
-- Indeks untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`IdPengguna`),
  ADD KEY `IdAkses` (`IdAkses`);

--
-- Indeks untuk tabel `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`IdPenjualan`),
  ADD KEY `IdPengguna` (`IdPengguna`),
  ADD KEY `IdBarang` (`IdBarang`),
  ADD KEY `IdPelanggan` (`IdPelanggan`);

--
-- Indeks untuk tabel `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`IdSupplier`);

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `barang`
--
ALTER TABLE `barang`
  ADD CONSTRAINT `barang_ibfk_1` FOREIGN KEY (`IdPengguna`) REFERENCES `pengguna` (`IdPengguna`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `barang_ibfk_2` FOREIGN KEY (`IdSupplier`) REFERENCES `supplier` (`IdSupplier`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD CONSTRAINT `pelanggan_ibfk_1` FOREIGN KEY (`IdPelanggan`) REFERENCES `penjualan` (`IdPelanggan`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `pembelian`
--
ALTER TABLE `pembelian`
  ADD CONSTRAINT `pembelian_ibfk_1` FOREIGN KEY (`IdBarang`) REFERENCES `barang` (`IdBarang`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  ADD CONSTRAINT `pengguna_ibfk_1` FOREIGN KEY (`IdAkses`) REFERENCES `hakakses` (`IdAkses`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `penjualan`
--
ALTER TABLE `penjualan`
  ADD CONSTRAINT `penjualan_ibfk_1` FOREIGN KEY (`IdBarang`) REFERENCES `barang` (`IdBarang`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
